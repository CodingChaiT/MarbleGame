﻿namespace _321_Assignment3
{
    partial class OpenFiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OpenFiles));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pbxPreview = new System.Windows.Forms.PictureBox();
            this.listViewFiles = new System.Windows.Forms.ListView();
            this.columnName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnSize = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDateModified = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.txtCurrentPath = new System.Windows.Forms.TextBox();
            this.lblGameSize = new System.Windows.Forms.Label();
            this.lblBallCount = new System.Windows.Forms.Label();
            this.lblWallCount = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPreview)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1205, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "Open";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(980, 26);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(192, 43);
            this.button2.TabIndex = 1;
            this.button2.Text = "Up One Level";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pbxPreview
            // 
            this.pbxPreview.Location = new System.Drawing.Point(67, 113);
            this.pbxPreview.Name = "pbxPreview";
            this.pbxPreview.Size = new System.Drawing.Size(547, 544);
            this.pbxPreview.TabIndex = 2;
            this.pbxPreview.TabStop = false;
            // 
            // listViewFiles
            // 
            this.listViewFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnName,
            this.columnSize,
            this.columnDateModified});
            this.listViewFiles.HideSelection = false;
            this.listViewFiles.Location = new System.Drawing.Point(648, 113);
            this.listViewFiles.Name = "listViewFiles";
            this.listViewFiles.Size = new System.Drawing.Size(744, 575);
            this.listViewFiles.SmallImageList = this.imageList1;
            this.listViewFiles.TabIndex = 3;
            this.listViewFiles.UseCompatibleStateImageBehavior = false;
            this.listViewFiles.View = System.Windows.Forms.View.Details;
            // 
            // columnName
            // 
            this.columnName.Text = "Name";
            this.columnName.Width = 275;
            // 
            // columnSize
            // 
            this.columnSize.Text = "Size";
            this.columnSize.Width = 98;
            // 
            // columnDateModified
            // 
            this.columnDateModified.Text = "DateModified";
            this.columnDateModified.Width = 288;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "green-file-folder-icon.jpg");
            this.imageList1.Images.SetKeyName(1, "mushroomGreen.png");
            // 
            // txtCurrentPath
            // 
            this.txtCurrentPath.Location = new System.Drawing.Point(67, 26);
            this.txtCurrentPath.Name = "txtCurrentPath";
            this.txtCurrentPath.Size = new System.Drawing.Size(787, 31);
            this.txtCurrentPath.TabIndex = 4;
            // 
            // lblGameSize
            // 
            this.lblGameSize.AutoSize = true;
            this.lblGameSize.Location = new System.Drawing.Point(67, 621);
            this.lblGameSize.Name = "lblGameSize";
            this.lblGameSize.Size = new System.Drawing.Size(0, 25);
            this.lblGameSize.TabIndex = 5;
            // 
            // lblBallCount
            // 
            this.lblBallCount.AutoSize = true;
            this.lblBallCount.Location = new System.Drawing.Point(190, 621);
            this.lblBallCount.Name = "lblBallCount";
            this.lblBallCount.Size = new System.Drawing.Size(0, 25);
            this.lblBallCount.TabIndex = 6;
            // 
            // lblWallCount
            // 
            this.lblWallCount.AutoSize = true;
            this.lblWallCount.Location = new System.Drawing.Point(325, 621);
            this.lblWallCount.Name = "lblWallCount";
            this.lblWallCount.Size = new System.Drawing.Size(0, 25);
            this.lblWallCount.TabIndex = 7;
            // 
            // OpenFiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1426, 874);
            this.Controls.Add(this.lblWallCount);
            this.Controls.Add(this.lblBallCount);
            this.Controls.Add(this.lblGameSize);
            this.Controls.Add(this.txtCurrentPath);
            this.Controls.Add(this.listViewFiles);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pbxPreview);
            this.Name = "OpenFiles";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.pbxPreview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pbxPreview;
        private System.Windows.Forms.ListView listViewFiles;
        private System.Windows.Forms.TextBox txtCurrentPath;
        private System.Windows.Forms.Label lblGameSize;
        private System.Windows.Forms.Label lblBallCount;
        private System.Windows.Forms.Label lblWallCount;
        private System.Windows.Forms.ColumnHeader columnName;
        private System.Windows.Forms.ColumnHeader columnSize;
        private System.Windows.Forms.ColumnHeader columnDateModified;
        private System.Windows.Forms.ImageList imageList1;
    }
}