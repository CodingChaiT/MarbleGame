﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Windows.Forms;
using _321_Assignment3;


namespace FileReader
{
    public partial class Form1 : Form


    {   /// <summary>
    /// My class level variables
    /// It sets up:
    /// The Game State
    /// Panels for layout
    /// Game clock
    /// Stopwatch for timing
    /// The laderboard + file paths
    /// </summary>
        private Image PuzzleImage = Image.FromFile("puzzle.jpg");
        //private Image PuzzleImage = Image.FromFile("puzzleTall.jpg");
        //private Image PuzzleImage = Image.FromFile("puzzleWide.jpg");
        private int BallCount = 3;
        private const int DRAWX = 130;
        private const int DRAWY = 106;
        private const int DRAWSIZE = 500;
        private bool ErrorCondition = false;
        private TableLayoutPanel mainPanel;
        private TableLayoutPanel puzzlePanel;
        private TableLayoutPanel gridPanel;
        private TableLayoutPanel puzzleSizerTlp;
        private TableLayoutPanel leaderboardPanel;

        private GameClock gameClock;
        private Timer clockTimer;
        private StopwatchManager stopwatchManager = new StopwatchManager();
        private Button btnStop;
        private Button btnReset;
        private Button btnPauseResume;
        private List<LeaderboardEntry> leaderboardEntries = new List<LeaderboardEntry>();
        private bool isPaused = false;
        private string archivePath;
        private string tempDirectory;
        int LeaderBoardMoves = 0;

        //private BufferedGraphicsContext CurrentContext;
        //private Point center;
        //private float radius;

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            if (gameClock != null)
            {
                gameClock.Draw(e.Graphics);
            }
        }






        private PuzzlePictureBox[,] pbxGrid;
        private int size;

        //This is my constructor. It builds the UI and prepares the form
        public Form1()
        {
            InitializeComponent();
            InitializePanels();
            CreatePauseButton();

            this.Resize += Form1_Resize;
        }

        private void BtnStop_Click(object sender, EventArgs e)
        {
            stopwatchManager.Stop();
            MessageBox.Show("Stopwatch stopped.");
        }

        private void BtnReset_Click(object sender, EventArgs e)
        {
            stopwatchManager.Reset();
            MessageBox.Show("Stopwatch reset.");
        }

        private void CreateControlButtons()
        {
            btnStop = new Button
            {
                Text = "Stop",
                Width = 100,
                Height = 30
            };
            btnStop.Click += BtnStop_Click;

            btnReset = new Button
            {
                Text = "Reset",
                Width = 100,
                Height = 30
            };
            btnReset.Click += BtnReset_Click;
            controlPanel.Controls.Add(btnStop);
            controlPanel.Controls.Add(btnReset);
        }

        //Creates my pause button for the game
        private void CreatePauseButton()
        {
            btnPauseResume = new Button
            {
                Text = "Pause",
                Width = 100,
                Height = 30,
                Dock = DockStyle.Top
            };
            btnPauseResume.Click += BtnPauseResume_Click;
            controlPanel.Controls.Add(btnPauseResume);
        }

        //This is activated when pause is clicked after the initial pause and resumes the stopwatch
        private void BtnPauseResume_Click(object sender, EventArgs e)
        {
            if (isPaused)
            {
                stopwatchManager.Start();
                clockTimer.Start();
                gridPanel.Visible = true;
                btnPauseResume.Text = "Pause";
            }
            else
            {
                stopwatchManager.Pause();
                clockTimer.Stop();
                gridPanel.Visible = false;
                btnPauseResume.Text = "Resume";
            }

            isPaused = !isPaused;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            OpenFiles openFilesDialog = new OpenFiles();
            openFilesDialog.FileSelected += OpenFilesDialog_FileSelected;
            openFilesDialog.ShowDialog(); 
        }


        private void OpenFilesDialog_FileSelected(string filePath)
        {

            string puzzleFile = Path.Combine(filePath, "puzzle.txt");

            if (File.Exists(puzzleFile))
            {
                // Read puzzle.txt and load the game
                LoadGame(puzzleFile);
            }
            else
            {
                MessageBox.Show("puzzle.txt not found in the selected path.");
            }
            archivePath = Path.Combine(filePath, "TheArchiveFile.mrb"); 
            tempDirectory = filePath;
            LoadLeaderboard(tempDirectory);  
            RefreshLeaderboardDisplay();


        }

        //Loads the game after user selected a .mrb file
        ///This is the heard of the loading: <summary>
        /// This is the heard of the loading:
        /// </summary>
        /// It reads puzzle size, balls, holes, walls
        /// sets up the visual gridPanel
        /// Initializes the GameClock
        /// Starts the timer to redraw it
        /// Starts the stopwatch
        /// <param name="puzzleFile"></param>
        private void LoadGame(string puzzleFile)
        {

            string[] lines = File.ReadAllLines(puzzleFile);
            string[] pieces = lines[0].Split(' ');

            size = int.Parse(pieces[0]);
            BallCount = int.Parse(pieces[1]);
            int wallCount = int.Parse(pieces[2]);

            // Clear existing grid
            gridPanel.Controls.Clear();
            gridPanel.RowStyles.Clear();
            gridPanel.ColumnStyles.Clear();
            gridPanel.Dock = DockStyle.Fill;


            // Reset grid layout
            gridPanel.RowCount = size;
            gridPanel.ColumnCount = size;

            for (int i = 0; i < size; i++)
            {
                gridPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / size));
                gridPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / size));
            }

            pbxGrid = new PuzzlePictureBox[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    var pb = new PuzzlePictureBox
                    {
                        Dock = DockStyle.Fill,
                        BorderStyle = BorderStyle.FixedSingle,
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Margin = new Padding(0)
                    };

                    pbxGrid[row, col] = pb;
                    gridPanel.Controls.Add(pb, col, row);
                }
            }

            int currentLine = 1;

            // Place Balls
            for (int i = 0; i < BallCount; i++)
            {
                string[] ballData = lines[currentLine].Split(' ');
                int row = int.Parse(ballData[0]);
                int col = int.Parse(ballData[1]);
                pbxGrid[row, col].Ball = i + 1;
                currentLine++;
            }

            // Place Holes
            for (int i = 0; i < BallCount; i++)
            {
                string[] holeData = lines[currentLine].Split(' ');
                int row = int.Parse(holeData[0]);
                int col = int.Parse(holeData[1]);
                pbxGrid[row, col].Hole = -(i + 1);
                currentLine++;
            }

            // Place Walls
            for (int i = 0; i < wallCount; i++)
            {
                string[] wallData = lines[currentLine].Split(' ');
                int r1 = int.Parse(wallData[0]);
                int c1 = int.Parse(wallData[1]);
                int r2 = int.Parse(wallData[2]);
                int c2 = int.Parse(wallData[3]);

                if (r1 == r2)
                {
                    if (c1 < c2)
                    {
                        pbxGrid[r1, c1].RightWall = true;
                        pbxGrid[r2, c2].LeftWall = true;
                    }
                    else
                    {
                        pbxGrid[r1, c1].LeftWall = true;
                        pbxGrid[r2, c2].RightWall = true;
                    }
                }
                else if (c1 == c2)
                {
                    if (r1 < r2)
                    {
                        pbxGrid[r1, c1].BottomWall = true;
                        pbxGrid[r2, c2].TopWall = true;
                    }
                    else
                    {
                        pbxGrid[r1, c1].TopWall = true;
                        pbxGrid[r2, c2].BottomWall = true;
                    }
                }

                currentLine++;
            }

            if (!tlpMain.Controls.Contains(gridPanel))
            {
                tlpMain.Controls.Add(gridPanel, 0, 0);
            }

  
            tlpMain.PerformLayout();
            gridPanel.PerformLayout();


            Point clockCenter = new Point(controlPanel.Width / 2, controlPanel.Height / 2);
            float clockRadius = Math.Min(controlPanel.Width, controlPanel.Height) / 2 - 10;

            gameClock = new GameClock(clockCenter, clockRadius);
            controlPanel.Invalidate(); // Force clock to draw immediately


            clockTimer = new Timer();
            clockTimer.Interval = 1000; // 1 second
            clockTimer.Tick += (s, e) => controlPanel.Invalidate();
            clockTimer.Start();



            this.Invalidate();


            UpdateImages();
            AdjustPuzzleSize();
            stopwatchManager.Reset();
            stopwatchManager.Start();


        }



        private void RefreshLeaderboardDisplay()
        {
            // Clear leaderboard rows except the header (row 0)
            for (int i = leaderboardPanel.RowCount - 1; i > 0; i--)
            {
                for (int j = 0; j < leaderboardPanel.ColumnCount; j++)
                {
                    var control = leaderboardPanel.GetControlFromPosition(j, i);
                    if (control != null)
                    {
                        leaderboardPanel.Controls.Remove(control);
                    }
                }
            }

            leaderboardPanel.RowCount = 1; 

            // Add top 5 entries
            int count = leaderboardEntries.Count < 5 ? leaderboardEntries.Count : 5;

            for (int i = 0; i < count; i++)
            {
                LeaderboardEntry entry = leaderboardEntries[i];
                leaderboardPanel.RowCount += 1;

                leaderboardPanel.Controls.Add(new System.Windows.Forms.Label() { Text = entry.Name, AutoSize = true }, 0, i + 1);
                leaderboardPanel.Controls.Add(new System.Windows.Forms.Label() { Text = entry.Moves.ToString(), AutoSize = true }, 1, i + 1);
                leaderboardPanel.Controls.Add(new System.Windows.Forms.Label() { Text = entry.TimeTaken.ToString(@"mm\:ss"), AutoSize = true }, 2, i + 1);
            }
        }


        //Leaderboard entries are stored in List<LeaderboardEntry>()
        private void LoadLeaderboard(string tempDirectory)
        {
            string leaderboardFile = Path.Combine(tempDirectory, "puzzle.bin");

            if (File.Exists(leaderboardFile))
            {
                IFormatter formatter = new BinaryFormatter();
                using (FileStream stream = new FileStream(leaderboardFile, FileMode.Open, FileAccess.Read))
                {
                    leaderboardEntries = (List<LeaderboardEntry>)formatter.Deserialize(stream);
                }
            }
            else
            {
                leaderboardEntries = new List<LeaderboardEntry>();
            }
        }




        private void SaveLeaderboardToFile(string tempDirectory)
        {
            string leaderboardFile = Path.Combine(tempDirectory, "puzzle.bin");
            IFormatter formatter = new BinaryFormatter();
            using (FileStream stream = new FileStream(leaderboardFile, FileMode.Create, FileAccess.Write))
            {
                formatter.Serialize(stream, leaderboardEntries);
            }
            RefreshLeaderboardDisplay();

        }

        //Promts user for a name to enter after game is won
        //Then returns it to the "Player" in the leadrerboard
        public static string PromptForName(string text, string caption)
        {
            Form prompt = new Form()
            {
                Width = 300,
                Height = 150,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen
            };

            System.Windows.Forms.Label textLabel = new System.Windows.Forms.Label()
            {
                Left = 10,
                Top = 20,
                Text = text,
                Width = 260
            };

            TextBox inputBox = new TextBox() { Left = 10, Top = 50, Width = 260 };
            Button confirmation = new Button()
            {
                Text = "OK",
                Left = 190,
                Width = 80,
                Top = 80,
                DialogResult = DialogResult.OK
            };

            confirmation.Click += (sender, clickArgs) => { prompt.Close(); };

            prompt.Controls.Add(confirmation);
            prompt.Controls.Add(textLabel);
            prompt.Controls.Add(inputBox);
            prompt.AcceptButton = confirmation;

            return prompt.ShowDialog() == DialogResult.OK ? inputBox.Text : "Player";
        }



        private void Form1_Resize(object sender, EventArgs e)
        {
            AdjustPuzzleSize();

            if (gameClock != null)
            {
                Point clockCenter = new Point(ClientSize.Width / 2, ClientSize.Height / 2);
                float clockRadius = Math.Min(ClientSize.Width, ClientSize.Height) / 2;
                gameClock.UpdateClock(clockCenter, clockRadius);
            }

            this.Invalidate(); // Forces redraw
        }






        private void btnImageLoad_Click(object sender, EventArgs e)
        {
            UpdateImages();
        }

        
        private (int, int) RowColumnGetterFromImageFunction(PuzzlePictureBox pb)

        {


            //get me the correct row and column to draw
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)

            {
                return (0, 0);
            }
            //me
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (0, 1);
            }
            //me
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                //return (2,0);
                return (0, 2);
            }
            //me
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (0, 3);
            }
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (0, 4);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (0, 5);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (0, 6);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 0);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 1);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 2);
            }
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 3);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 4);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 5);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball == 0)
            {
                return (1, 6);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (2, 0);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball == 0)
            {
                return (2, 1);
            }




            //holes conditions
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (2, 2);
            }
            //me
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (2, 3);
            }
            //me
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (2, 4);
            }
            //me
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (2, 5);
            }
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (2, 6);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 0);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 1);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 2);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 3);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 4);
            }
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 5);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (3, 6);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (4, 0);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == false && pb.Hole < 0 && pb.Ball == 0)
            {
                return (4, 1);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (4, 2);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == true && pb.Hole < 0 && pb.Ball == 0)
            {
                return (4, 3);
            }



            //ball conditions
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (4, 4);
            }
            //me
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                //return (5, 4);
                return (4, 5);
            }
            //me
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (4, 6);
            }
            //me
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 0);
            }
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == true && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 1);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 2);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 3);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == false && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 4);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 5);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == true && pb.Hole == 0 && pb.Ball > 0)
            {
                return (5, 6);
            }
            if (pb.LeftWall == false && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball > 0)
            {
                return (6, 0);
            }
            if (pb.LeftWall == true && pb.RightWall == false && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball > 0)
            {
                return (6, 1);
            }
            if (pb.LeftWall == false && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == true && pb.Hole == 0 && pb.Ball > 0)
            {
                return (6, 2);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == false && pb.Hole == 0 && pb.Ball > 0)
            {
                return (6, 3);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == false && pb.BottomWall == true && pb.Hole == 0 && pb.Ball > 0)
            {
                return (6, 4);
            }
            if (pb.LeftWall == true && pb.RightWall == true && pb.TopWall == true && pb.BottomWall == true & pb.Hole == 0 && pb.Ball > 0)
            {
                return (6, 5);
            }

            if (pb.ErrorCondition == true)
            {
                return (6, 6);

            }

            return (6, 6);

            // return (-1, -1);
        }

        //public (int, int) Error()
        //{
        //    if (ErrorCondition) 
        //    {
        //        return (6, 6);  
        //    }

        //    return (0, 0);  
        //}
        private void SetErrorCondition(int row, int col)
        {
            int errorRow = Math.Min(size - 1, 6);
            int errorCol = Math.Min(size - 1, 6);

            Bitmap bm = new Bitmap(pbxGrid[errorRow, errorCol].Width, pbxGrid[errorRow, errorCol].Height);
            using (Graphics g = Graphics.FromImage(bm))
            {
                Rectangle r = new Rectangle(0, 0, bm.Width, bm.Height);

                g.DrawImage(PuzzleImage, r,
                            PuzzleImage.Width * 6 / 7, PuzzleImage.Height * 6 / 7,  // (7,7) portion of the image
                            PuzzleImage.Width / 7, PuzzleImage.Height / 7, GraphicsUnit.Pixel);
            }

            pbxGrid[errorRow, errorCol].Image = bm;
            pbxGrid[errorRow, errorCol].SizeMode = PictureBoxSizeMode.StretchImage;
            pbxGrid[errorRow, errorCol].Visible = true;
        }








        //Updates the puzzle as the player plays
        ///This figures out what image to draw on each tile based on where the balls, walls, and holes are.
        ///It uses RowColumnGetterFunction() (the million if statement function)to map out the walls/balls/holes
        private void UpdateImages()
        {
            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    int pbxRow, pbxCol;
                    (pbxRow, pbxCol) = RowColumnGetterFromImageFunction(pbxGrid[row, col]);

                    Bitmap bm = new Bitmap(pbxGrid[row, col].Width, pbxGrid[row, col].Height);
                    using (Graphics g = Graphics.FromImage(bm))
                    {
                        Rectangle r = new Rectangle(0, 0, bm.Width, bm.Height);

                        // Draw the puzzle image section
                        g.DrawImage(PuzzleImage, r,
                                    PuzzleImage.Width * pbxCol / 7, PuzzleImage.Height * pbxRow / 7,
                                    PuzzleImage.Width / 7, PuzzleImage.Height / 7, GraphicsUnit.Pixel);

                        // Check if this PictureBox contains a ball
                        if (pbxGrid[row, col].Ball > 0)
                        {
                            Font font = new Font("Arial", 20, FontStyle.Bold);
                            Brush brush = new SolidBrush(Color.Red);
                            StringFormat format = new StringFormat
                            {
                                Alignment = StringAlignment.Center,
                                LineAlignment = StringAlignment.Center
                            };

                            g.DrawString(pbxGrid[row, col].Ball.ToString(), font, brush, r, format);
                        }

                        // Check if this PictureBox contains a hole
                        else if (pbxGrid[row, col].Hole < 0)
                        {
                            Font font = new Font("Arial", 20, FontStyle.Bold);
                            Brush brush = new SolidBrush(Color.Blue);
                            StringFormat format = new StringFormat
                            {
                                Alignment = StringAlignment.Center,
                                LineAlignment = StringAlignment.Center
                            };

                            g.DrawString((-pbxGrid[row, col].Hole).ToString(), font, brush, r, format);
                        }
                    }


                    pbxGrid[row, col].Image = bm;
                }
            }
        }



        private bool RollRight(int row, int col)
        {
            //1. if there's a wall/edge of the board
            //2. if there's a ball
            //3. if there's a hole
            //3.a could be the right hole
            //3.b could be the wrong hole
            while (col < size - 1)
            {
                if (pbxGrid[row, col].RightWall)
                {
                    break;
                }
                else if (pbxGrid[row, col + 1].Ball > 0)
                {
                    break;
                }
                else if (pbxGrid[row, col + 1].Hole < 0)
                {
                    if (pbxGrid[row, col].Ball == Math.Abs(pbxGrid[row, col + 1].Hole))
                    {

                        pbxGrid[row, col].Ball = 0;
                        pbxGrid[row, col + 1].Ball = 0;
                        BallCount--;

                        return true;
                    }
                    else
                    {

                        SetErrorCondition(6, 6);
                        return false;
                    }
                }
                else
                {
                    pbxGrid[row, col + 1].Ball = pbxGrid[row, col].Ball;
                    pbxGrid[row, col].Ball = 0;
                }

                col++; //Move right
            }

            return true;
        }

        private bool RollLeft(int row, int col)
        {
            // 1. If there's a wall/edge of the board
            // 2. If there's a ball
            // 3. If there's a hole
            // 3.a Could be the left hole
            // 3.b Could be the wrong hole
            while (col > 0)
            {
                if (pbxGrid[row, col].LeftWall)
                {
                    break; // Stop moving
                }
                else if (pbxGrid[row, col - 1].Ball > 0)
                {
                    break;
                }
                else if (pbxGrid[row, col - 1].Hole < 0)
                {
                    if (pbxGrid[row, col].Ball == Math.Abs(pbxGrid[row, col - 1].Hole))
                    {

                        pbxGrid[row, col].Ball = 0;
                        pbxGrid[row, col - 1].Ball = 0;
                        BallCount--;
                        return true;
                    }
                    else
                    {

                        SetErrorCondition(6, 6);
                        return false;
                    }
                }
                else
                {
                    pbxGrid[row, col - 1].Ball = pbxGrid[row, col].Ball;
                    pbxGrid[row, col].Ball = 0;
                }

                col--; // Move left
            }

            return true;
        }

        private bool RollUp(int row, int col)
        {

            while (row > 0)
            {

                if (pbxGrid[row - 1, col].TopWall)
                {
                    break;
                }

                else if (pbxGrid[row - 1, col].Ball > 0)
                {
                    break;
                }

                else if (pbxGrid[row - 1, col].Hole < 0)
                {
                    if (pbxGrid[row, col].Ball == Math.Abs(pbxGrid[row - 1, col].Hole))
                    {
                        pbxGrid[row, col].Ball = 0;
                        pbxGrid[row - 1, col].Ball = 0;
                        BallCount--;
                        return true;
                    }
                    else
                    {

                        SetErrorCondition(6, 6);
                        return false;
                    }
                }

                else
                {
                    pbxGrid[row - 1, col].Ball = pbxGrid[row, col].Ball;
                    pbxGrid[row, col].Ball = 0;
                }
                row--; // Move up row
            }

            return true;
        }


        private bool RollDown(int row, int col)
        {
            //1. if there's a wall/edge of the board
            //2. if there's a ball
            //3. if there's a hole
            //3.a could be the bottom hole
            //3.b could be the wrong hole
            while (row < size - 1)
            {
                if (pbxGrid[row, col].BottomWall)
                {
                    break; //true?
                }
                else if (pbxGrid[row + 1, col].Ball > 0)
                {
                    break; //true?
                }
                else if (pbxGrid[row + 1, col].Hole < 0)
                {
                    if (pbxGrid[row, col].Ball == Math.Abs(pbxGrid[row + 1, col].Hole))
                    {
                        pbxGrid[row, col].Ball = 0;
                        pbxGrid[row + 1, col].Hole = 0;

                        BallCount--;
                        break; //true?
                    }
                    else
                    {
                        SetErrorCondition(6, 6);
                        return false;
                    }
                }
                else
                {
                    pbxGrid[row + 1, col].Ball = pbxGrid[row, col].Ball;
                    pbxGrid[row, col].Ball = 0;
                }
                row++;
            }

            //BallCount--;
            return true;
        }


        private void btnRight_Click(object sender, EventArgs e)
        {
            //What if we win?
            for (int row = 0; row < size; row++)
            {

                for (int col = size - 2; col >= 0; col--)
                {
                    if (pbxGrid[row, col].Ball > 0)
                    {
                        if (!RollRight(row, col))
                        {
                            SetErrorCondition(6, 6);

                        }
                    }

                }
                UpdateImages();


                if (BallCount == 0)
                {
                    stopwatchManager.Stop();
                    MessageBox.Show($"You Win! Time: {stopwatchManager.Elapsed:mm\\:ss}");

                    string playerName = PromptForName("Enter your name:", "Victory!");

                    LeaderboardEntry newEntry = new LeaderboardEntry(playerName, LeaderBoardMoves, stopwatchManager.Elapsed);
                    leaderboardEntries.Add(newEntry);

                    leaderboardEntries = leaderboardEntries
                        .OrderBy(entry => entry.Moves)
                        .ThenBy(entry => entry.TimeTaken)
                        .Take(5)
                        .ToList();

                    // Save to puzzle.bin in the temp directory
                    SaveLeaderboardToFile(tempDirectory); 

                    using (ZipArchive archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
                    {
                        var oldEntry = archive.GetEntry("puzzle.bin");
                        oldEntry?.Delete();

                        ZipArchiveEntry newEntryZip = archive.CreateEntry("puzzle.bin");
                        using (Stream entryStream = newEntryZip.Open())
                        using (FileStream fs = new FileStream(Path.Combine(tempDirectory, "puzzle.bin"), FileMode.Open, FileAccess.Read))
                        {
                            fs.CopyTo(entryStream);
                        }
                    }
                    string display = "Leaderboard:\n";
                    for (int i = 0; i < leaderboardEntries.Count; i++)
                    {
                        LeaderboardEntry entry = leaderboardEntries[i];
                        display += $"{i + 1}. {entry.Name} - Moves: {entry.Moves}, Time: {entry.TimeTaken:mm\\:ss}\n";
                    }

                    MessageBox.Show(display);


                    return;
                }

            }
            //UpdateImages();

            //if (BallCount == 0)
            //{
            //    MessageBox.Show("You Win!");
            //}
            LeaderBoardMoves++;
        }
        private void btn_Left_Click(object sender, EventArgs e)
        {
            // What if we win?
            for (int row = 0; row < size; row++)
            {

                for (int col = 1; col < size; col++)
                {
                    if (pbxGrid[row, col].Ball > 0)
                    {
                        if (!RollLeft(row, col))
                        {
                            SetErrorCondition(6, 6);

                        }
                    }
                }
                UpdateImages();

                if (BallCount == 0)
                {
                    stopwatchManager.Stop();
                    MessageBox.Show($"You Win! Time: {stopwatchManager.Elapsed:mm\\:ss}");

                    string playerName = PromptForName("Enter your name:", "Victory!");

                    LeaderboardEntry newEntry = new LeaderboardEntry(playerName, LeaderBoardMoves, stopwatchManager.Elapsed);
                    leaderboardEntries.Add(newEntry);

                    leaderboardEntries = leaderboardEntries
                        .OrderBy(entry => entry.Moves)
                        .ThenBy(entry => entry.TimeTaken)
                        .Take(5)
                        .ToList();

                    // Save to puzzle.bin in the temp directory
                    SaveLeaderboardToFile(tempDirectory); 
                    using (ZipArchive archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
                    {
                        var oldEntry = archive.GetEntry("puzzle.bin");
                        oldEntry?.Delete();

                        ZipArchiveEntry newEntryZip = archive.CreateEntry("puzzle.bin");
                        using (Stream entryStream = newEntryZip.Open())
                        using (FileStream fs = new FileStream(Path.Combine(tempDirectory, "puzzle.bin"), FileMode.Open, FileAccess.Read))
                        {
                            fs.CopyTo(entryStream);
                        }
                    }
                    string display = "Leaderboard:\n";
                    for (int i = 0; i < leaderboardEntries.Count; i++)
                    {
                        LeaderboardEntry entry = leaderboardEntries[i];
                        display += $"{i + 1}. {entry.Name} - Moves: {entry.Moves}, Time: {entry.TimeTaken:mm\\:ss}\n";
                    }

                    MessageBox.Show(display);

                    return;
                }

            }
            // UpdateImages();

            // if(ballcount==0)
            // MessageBox.Show("You Win!")
            LeaderBoardMoves++;
        }


        
        private void btn_UP_Click(object sender, EventArgs e)
        {
            // What if we win?
            for (int col = 0; col < size; col++)
            {

                for (int row = 1; row < size; row++)
                {
                    if (pbxGrid[row, col].Ball > 0)
                    {
                        if (!RollUp(row, col))
                        {
                            SetErrorCondition(6, 6);
                        }
                    }
                }
                UpdateImages();
                if (BallCount == 0)
                {
                    stopwatchManager.Stop();
                    MessageBox.Show($"You Win! Time: {stopwatchManager.Elapsed:mm\\:ss}");

                    string playerName = PromptForName("Enter your name:", "Victory!");

                    LeaderboardEntry newEntry = new LeaderboardEntry(playerName, LeaderBoardMoves, stopwatchManager.Elapsed);
                    leaderboardEntries.Add(newEntry);

                    leaderboardEntries = leaderboardEntries
                        .OrderBy(entry => entry.Moves)
                        .ThenBy(entry => entry.TimeTaken)
                        .Take(5)
                        .ToList();

                    // Save to puzzle.bin in the temp directory
                    SaveLeaderboardToFile(tempDirectory); 
                    using (ZipArchive archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
                    {
                        var oldEntry = archive.GetEntry("puzzle.bin");
                        oldEntry?.Delete();

                        ZipArchiveEntry newEntryZip = archive.CreateEntry("puzzle.bin");
                        using (Stream entryStream = newEntryZip.Open())
                        using (FileStream fs = new FileStream(Path.Combine(tempDirectory, "puzzle.bin"), FileMode.Open, FileAccess.Read))
                        {
                            fs.CopyTo(entryStream);
                        }
                    }
                    string display = "Leaderboard:\n";
                    for (int i = 0; i < leaderboardEntries.Count; i++)
                    {
                        LeaderboardEntry entry = leaderboardEntries[i];
                        display += $"{i + 1}. {entry.Name} - Moves: {entry.Moves}, Time: {entry.TimeTaken:mm\\:ss}\n";
                    }

                    MessageBox.Show(display);

                    return;
                }


            }
            //UpdateImages();

            //if (BallCount == 0)
            //{
            //    MessageBox.Show("You Win!");
            //}
            LeaderBoardMoves++;
        }
        private void btn_Down_Click(object sender, EventArgs e)
        {

            for (int col = 0; col < size; col++)
            {

                for (int row = size - 2; row >= 0; row--)
                {
                    if (pbxGrid[row, col].Ball > 0)
                    {
                        if (!RollDown(row, col))
                        {
                            SetErrorCondition(6, 6);
                        }
                    }
                }



               
                UpdateImages();

                if (BallCount == 0)
                {
                    stopwatchManager.Stop();
                    MessageBox.Show($"You Win! Time: {stopwatchManager.Elapsed:mm\\:ss}");

                    string playerName = PromptForName("Enter your name:", "Victory!");

                    LeaderboardEntry newEntry = new LeaderboardEntry(playerName, LeaderBoardMoves, stopwatchManager.Elapsed);
                    leaderboardEntries.Add(newEntry);

                    leaderboardEntries = leaderboardEntries
                        .OrderBy(entry => entry.Moves)
                        .ThenBy(entry => entry.TimeTaken)
                        .Take(5)
                        .ToList();

                    // Save to puzzle.bin in the temp directory
                    SaveLeaderboardToFile(tempDirectory); 
                    using (ZipArchive archive = ZipFile.Open(archivePath, ZipArchiveMode.Update))
                    {
                        var oldEntry = archive.GetEntry("puzzle.bin");
                        oldEntry?.Delete();

                        ZipArchiveEntry newEntryZip = archive.CreateEntry("puzzle.bin");
                        using (Stream entryStream = newEntryZip.Open())
                        using (FileStream fs = new FileStream(Path.Combine(tempDirectory, "puzzle.bin"), FileMode.Open, FileAccess.Read))
                        {
                            fs.CopyTo(entryStream);
                        }
                    }
                    string display = "Leaderboard:\n";
                    for (int i = 0; i < leaderboardEntries.Count; i++)
                    {
                        LeaderboardEntry entry = leaderboardEntries[i];
                        display += $"{i + 1}. {entry.Name} - Moves: {entry.Moves}, Time: {entry.TimeTaken:mm\\:ss}\n";
                    }

                    MessageBox.Show(display);

                    return;
                }



            }
            LeaderBoardMoves++;
        }


        //This initializes the panels, adds the buttons, leaderboard, puzzle display
        private void InitializePanels()
        {
            mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill
            };

            puzzlePanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true
            };


            gridPanel = new TableLayoutPanel();
            gridPanel.Dock = DockStyle.Fill;
            gridPanel.Margin = new Padding(0);
            gridPanel.Padding = new Padding(0);



            puzzlePanel.Controls.Add(gridPanel);
            mainPanel.Controls.Add(puzzlePanel);
            controlPanel.Paint += ClockPanel_Paint;
          
            CreateControlButtons(); 

            //The Leaderboard
            Controls.Add(mainPanel);
            leaderboardPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Bottom,
                AutoSize = true,
                ColumnCount = 3,
                RowCount = 5,
                CellBorderStyle = TableLayoutPanelCellBorderStyle.Single
            };

           
            leaderboardPanel.Controls.Add(new System.Windows.Forms.Label() { Text = "Name", AutoSize = true },0,0);
            leaderboardPanel.Controls.Add(new System.Windows.Forms.Label() { Text = "Moves", AutoSize = true }, 1, 0);
            leaderboardPanel.Controls.Add(new System.Windows.Forms.Label() { Text = "Time", AutoSize = true }, 3, 0);

            //The Clock
            controlPanel.Controls.Add(leaderboardPanel); 
            Panel clockPanel = new Panel
            {
                Dock = DockStyle.Right, 
                Width = 150, 
                BackColor = Color.White
            };
            clockPanel.Paint += ClockPanel_Paint;
            puzzlePanel.Controls.Add(clockPanel);

        }

    //Paints the clock on the panel for form adjustments
      private void ClockPanel_Paint(object sender, PaintEventArgs e)
{
         if (gameClock != null)
         {
        Panel panel = sender as Panel;
        Point clockCenter = new Point(panel.Width / 2, panel.Height / 2);
        float clockRadius = Math.Min(panel.Width, panel.Height) / 2 - 10;
        gameClock.UpdateClock(clockCenter, clockRadius);
        gameClock.Draw(e.Graphics);
         }
      }



        //Adusts the images within the panels
        private void AdjustPuzzleSize()
        {
            if (size == 0 || tlpMain == null || puzzleSizerTlp == null || gridPanel == null)
                return;

            int imgW = PuzzleImage.Width;
            int imgH = PuzzleImage.Height;

            int availW = tlpMain.ClientSize.Width;
            int availH = tlpMain.ClientSize.Height;

            float imgRatio = imgW / (float)imgH;
            float screenRatio = availW / (float)availH;

            int targetW, targetH;

            if (imgRatio > screenRatio)
            {
                // Wider image
                targetW = availW;
                targetH = (int)(availW / imgRatio);
            }
            else
            {
                // Taller image
                targetH = availH;
                targetW = (int)(availH * imgRatio);
            }

           
            int controlHeight = controlPanel?.Height ?? 0;

          
            puzzleSizerTlp.Width = targetW;
            puzzleSizerTlp.Height = targetH;

          
            int cellSize = Math.Min(targetW / size, targetH / size);
            int gridWidth = cellSize * size;
            int gridHeight = cellSize * size;

            gridPanel.Width = gridWidth;
            gridPanel.Height = gridHeight;

            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    pbxGrid[row, col].Width = cellSize;
                    pbxGrid[row, col].Height = cellSize;
                }
            }

  
            gridPanel.Left = (targetW - gridWidth) / 2;
            gridPanel.Top = (targetH - gridHeight - controlHeight) / 2;

           
            puzzleSizerTlp.PerformLayout();
            gridPanel.PerformLayout();
            tlpMain.PerformLayout();
            this.Invalidate();
        }

       
    }




    //Allows for leaderboard entry of name, Moves, Time
    [Serializable]
    public class LeaderboardEntry
    {
        public string Name { get; set; }
        public int Moves { get; set; }
        public TimeSpan TimeTaken { get; set; }

        public LeaderboardEntry() { }

        public LeaderboardEntry(string name, int moves, TimeSpan timeTaken)
        {
            Name = name;
            Moves = moves;
            TimeTaken = timeTaken;
        }

        public override string ToString()
        {
            return $"{Name} - Moves: {Moves}, Time: {TimeTaken:mm\\:ss}";
        }
    }



    //This controls the tracking of the time for the StopWatch
        /// <summary>
        /// Checks if the clock is running which is triggered by opening the game. Controls pause, start, and stop actions
        /// </summary>
    public class StopwatchManager
    {
        private Stopwatch stopwatch;
        private bool isPaused;

        public StopwatchManager()
        {
            stopwatch = new Stopwatch();
            isPaused = false;
        }

        public void Start()
        {
            if (!stopwatch.IsRunning && !isPaused)
            {
                stopwatch.Start();
            }
            else if (isPaused)
            {
                stopwatch.Start();
                isPaused = false;
            }
        }

        public void Stop()
        {
            if (stopwatch.IsRunning || isPaused)
            {
                stopwatch.Stop();
                isPaused = false;
            }
        }

        public void Pause()
        {
            if (stopwatch.IsRunning)
            {
                stopwatch.Stop();
                isPaused = true;
            }
        }

        public void Reset()
        {
            stopwatch.Reset();
            isPaused = false;
        }

        public int ElapsedSeconds => (int)stopwatch.Elapsed.TotalSeconds;

        public int ElapsedMinutes => (int)stopwatch.Elapsed.TotalMinutes;

        public TimeSpan Elapsed => stopwatch.Elapsed;
    }



    //A custom class that draws a real-time analog clock 
        /// <summary>
        /// includes tick marks, numbers (1-12), an hour, minutes, and second hand
        /// it is rendered using the Graphics object inside a Paint event
        /// This means every second the panel invalidates and triggers a redraw of the clock
        /// </summary>
    public class GameClock
    {
        private Point center;
        private float radius;

        public GameClock(Point center, float radius)
        {
            this.center = center;
            this.radius = radius;
        }

        public void Draw(Graphics g)
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.Clear(Color.White);

            AddTickMarks(g);
            AddNumbers(g);
            AddHands(g);
        }

        private void AddTickMarks(Graphics g)
        {
            Pen p = new Pen(Color.Black, radius / 30);
            Pen p2 = new Pen(Color.Black, radius / 50);
            Pen p3 = new Pen(Color.Red, radius / 25);

            for (int i = 1; i < 13; i++)
            {
                float angle = i * 30 * (float)Math.PI / 180;
                float x1 = (float)Math.Cos(angle) * radius * 0.70f + center.X;
                float y1 = (float)Math.Sin(angle) * radius * 0.70f + center.Y;
                float x2 = (float)Math.Cos(angle) * radius * 0.80f + center.X;
                float y2 = (float)Math.Sin(angle) * radius * 0.80f + center.Y;
                g.DrawLine(p, x1, y1, x2, y2);
            }

            for (int i = 1; i < 61; i++)
            {
                float angle = i * 6 * (float)Math.PI / 180;
                float x1 = (float)Math.Cos(angle) * radius * 0.75f + center.X;
                float y1 = (float)Math.Sin(angle) * radius * 0.75f + center.Y;
                float x2 = (float)Math.Cos(angle) * radius * 0.80f + center.X;
                float y2 = (float)Math.Sin(angle) * radius * 0.80f + center.Y;
                g.DrawLine(p2, x1, y1, x2, y2);
            }

            for (int i = 1; i < 5; i++)
            {
                float angle = i * 90 * (float)Math.PI / 180;
                float x1 = (float)Math.Cos(angle) * radius * 0.65f + center.X;
                float y1 = (float)Math.Sin(angle) * radius * 0.65f + center.Y;
                float x2 = (float)Math.Cos(angle) * radius * 0.80f + center.X;
                float y2 = (float)Math.Sin(angle) * radius * 0.80f + center.Y;
                g.DrawLine(p3, x1, y1, x2, y2);
            }
        }

        private void AddNumbers(Graphics g)
        {
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;
            sf.LineAlignment = StringAlignment.Center;

            Font numFont = new Font("Tahoma", radius / 18f, FontStyle.Bold);
            Brush numBrush = new SolidBrush(Color.Black);

            for (int i = 1; i < 13; i++)
            {
                float x1 = (float)Math.Cos((i * 30 - 90) * Math.PI / 180) * radius * .90f + center.X;
                float y1 = (float)Math.Sin((i * 30 - 90) * Math.PI / 180) * radius * .90f + center.Y;

                g.DrawString(i.ToString(), numFont, numBrush, x1, y1, sf);
            }


        }

        private void AddHands(Graphics g)
        {
            Pen pHour = new Pen(Color.Black, radius / 25);
            Pen pMinute = new Pen(Color.Black, radius / 30);
            Pen pSecond = new Pen(Color.Red, radius / 50);

            DateTime now = DateTime.Now;

            float xHour = (float)Math.Cos((now.Hour * 30 - 90) * Math.PI / 180) * radius * .40f + center.X;
            float yHour = (float)Math.Sin((now.Hour * 30 - 90) * Math.PI / 180) * radius * .40f + center.Y;
            //float xHour = (float)Math.Cos((now.Hour * 30 + now.Minute / 2 - 90) * Math.PI / 180) * radius * .40f + center.X;
            //float yHour = (float)Math.Sin((now.Hour * 30 + now.Minute/2 - 90) * Math.PI / 180) * radius * .40f + center.Y;

            float xMinutes = (float)Math.Cos((now.Minute * 6 - 90) * Math.PI / 180) * radius * .60f + center.X;
            float yMinutes = (float)Math.Sin((now.Minute * 6 - 90) * Math.PI / 180) * radius * .60f + center.Y;

            float xSeconds = (float)Math.Cos((now.Second * 6 - 90) * Math.PI / 180) * radius * .80f + center.X;
            float ySeconds = (float)Math.Sin((now.Second * 6 - 90) * Math.PI / 180) * radius * .80f + center.Y;

            g.DrawLine(pHour, center.X, center.Y, xHour, yHour);
            g.DrawLine(pMinute, center.X, center.Y, xMinutes, yMinutes);
            g.DrawLine(pSecond, center.X, center.Y, xSeconds, ySeconds);
        }

        private PointF PolarToCartesian(float angleDegrees, float length)
        {
            float angle = angleDegrees * (float)Math.PI / 180;
            float x = (float)Math.Cos(angle) * length + center.X;
            float y = (float)Math.Sin(angle) * length + center.Y;
            return new PointF(x, y);
        }

        public void UpdateClock(Point newCenter, float newRadius)
        {
            center = newCenter;
            radius = newRadius;
        }
    }

}