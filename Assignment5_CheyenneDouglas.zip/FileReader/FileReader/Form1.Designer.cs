﻿namespace FileReader
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.txtRow = new System.Windows.Forms.TextBox();
            this.txtCol = new System.Windows.Forms.TextBox();
            this.lblRow = new System.Windows.Forms.Label();
            this.lblCol = new System.Windows.Forms.Label();
            this.btnImageLoad = new System.Windows.Forms.Button();
            this.tlpMain = new System.Windows.Forms.TableLayoutPanel();
            this.controlPanel = new System.Windows.Forms.TableLayoutPanel();
            this.btn_Down = new System.Windows.Forms.Button();
            this.btn_UP = new System.Windows.Forms.Button();
            this.btn_Left = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.GameClock = new System.Windows.Forms.Timer(this.components);
            this.tlpMain.SuspendLayout();
            this.controlPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(4, 4);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "Select File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtRow
            // 
            this.txtRow.Location = new System.Drawing.Point(883, 18);
            this.txtRow.Margin = new System.Windows.Forms.Padding(4);
            this.txtRow.Name = "txtRow";
            this.txtRow.Size = new System.Drawing.Size(80, 31);
            this.txtRow.TabIndex = 1;
            this.txtRow.Text = "1";
            // 
            // txtCol
            // 
            this.txtCol.Location = new System.Drawing.Point(1033, 17);
            this.txtCol.Margin = new System.Windows.Forms.Padding(4);
            this.txtCol.Name = "txtCol";
            this.txtCol.Size = new System.Drawing.Size(80, 31);
            this.txtCol.TabIndex = 2;
            this.txtCol.Text = "2";
            // 
            // lblRow
            // 
            this.lblRow.AutoSize = true;
            this.lblRow.Location = new System.Drawing.Point(836, 21);
            this.lblRow.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRow.Name = "lblRow";
            this.lblRow.Size = new System.Drawing.Size(54, 25);
            this.lblRow.TabIndex = 3;
            this.lblRow.Text = "Row";
            // 
            // lblCol
            // 
            this.lblCol.AutoSize = true;
            this.lblCol.Location = new System.Drawing.Point(987, 22);
            this.lblCol.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCol.Name = "lblCol";
            this.lblCol.Size = new System.Drawing.Size(44, 25);
            this.lblCol.TabIndex = 4;
            this.lblCol.Text = "Col";
            // 
            // btnImageLoad
            // 
            this.btnImageLoad.Location = new System.Drawing.Point(1137, 14);
            this.btnImageLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnImageLoad.Name = "btnImageLoad";
            this.btnImageLoad.Size = new System.Drawing.Size(100, 28);
            this.btnImageLoad.TabIndex = 5;
            this.btnImageLoad.Text = "Load Image";
            this.btnImageLoad.UseVisualStyleBackColor = true;
            this.btnImageLoad.Click += new System.EventHandler(this.btnImageLoad_Click);
            // 
            // tlpMain
            // 
            this.tlpMain.ColumnCount = 2;
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 300F));
            this.tlpMain.Controls.Add(this.controlPanel, 1, 0);
            this.tlpMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpMain.Location = new System.Drawing.Point(0, 0);
            this.tlpMain.Margin = new System.Windows.Forms.Padding(4);
            this.tlpMain.Name = "tlpMain";
            this.tlpMain.RowCount = 1;
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tlpMain.Size = new System.Drawing.Size(1118, 607);
            this.tlpMain.TabIndex = 10;
            // 
            // controlPanel
            // 
            this.controlPanel.ColumnCount = 3;
            this.controlPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33F));
            this.controlPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.34F));
            this.controlPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33F));
            this.controlPanel.Controls.Add(this.button1, 0, 0);
            this.controlPanel.Controls.Add(this.btn_UP, 1, 1);
            this.controlPanel.Controls.Add(this.btn_Down, 1, 2);
            this.controlPanel.Controls.Add(this.btnRight, 2, 2);
            this.controlPanel.Controls.Add(this.btn_Left, 0, 2);
            this.controlPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.controlPanel.GrowStyle = System.Windows.Forms.TableLayoutPanelGrowStyle.FixedSize;
            this.controlPanel.Location = new System.Drawing.Point(822, 4);
            this.controlPanel.Margin = new System.Windows.Forms.Padding(4);
            this.controlPanel.Name = "controlPanel";
            this.controlPanel.RowCount = 4;
            this.controlPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.controlPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.controlPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.controlPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.controlPanel.Size = new System.Drawing.Size(292, 599);
            this.controlPanel.TabIndex = 11;
            this.controlPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.controlPanel_Paint_1);
            // 
            // btn_Down
            // 
            this.btn_Down.BackgroundImage = global::FileReader.Properties.Resources.R__3_;
            this.btn_Down.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Down.Location = new System.Drawing.Point(101, 204);
            this.btn_Down.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Down.Name = "btn_Down";
            this.btn_Down.Size = new System.Drawing.Size(89, 89);
            this.btn_Down.TabIndex = 9;
            this.btn_Down.Text = "Roll Down";
            this.btn_Down.UseVisualStyleBackColor = true;
            this.btn_Down.Click += new System.EventHandler(this.btn_Down_Click);
            // 
            // btn_UP
            // 
            this.btn_UP.BackColor = System.Drawing.SystemColors.Control;
            this.btn_UP.BackgroundImage = global::FileReader.Properties.Resources.UP__3_;
            this.btn_UP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_UP.Location = new System.Drawing.Point(101, 104);
            this.btn_UP.Margin = new System.Windows.Forms.Padding(4);
            this.btn_UP.Name = "btn_UP";
            this.btn_UP.Size = new System.Drawing.Size(89, 72);
            this.btn_UP.TabIndex = 7;
            this.btn_UP.Text = "Roll Up";
            this.btn_UP.UseVisualStyleBackColor = false;
            this.btn_UP.Click += new System.EventHandler(this.btn_UP_Click);
            // 
            // btn_Left
            // 
            this.btn_Left.BackgroundImage = global::FileReader.Properties.Resources.Left_3_;
            this.btn_Left.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Left.Location = new System.Drawing.Point(4, 204);
            this.btn_Left.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Left.Name = "btn_Left";
            this.btn_Left.Size = new System.Drawing.Size(89, 55);
            this.btn_Left.TabIndex = 8;
            this.btn_Left.Text = "Roll Left";
            this.btn_Left.UseVisualStyleBackColor = true;
            this.btn_Left.Click += new System.EventHandler(this.btn_Left_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackgroundImage = global::FileReader.Properties.Resources.Right__3_;
            this.btnRight.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRight.Location = new System.Drawing.Point(198, 204);
            this.btnRight.Margin = new System.Windows.Forms.Padding(4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(90, 55);
            this.btnRight.TabIndex = 6;
            this.btnRight.Text = "Roll Right";
            this.btnRight.UseVisualStyleBackColor = true;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1118, 607);
            this.Controls.Add(this.tlpMain);
            this.Controls.Add(this.btnImageLoad);
            this.Controls.Add(this.lblCol);
            this.Controls.Add(this.lblRow);
            this.Controls.Add(this.txtCol);
            this.Controls.Add(this.txtRow);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tlpMain.ResumeLayout(false);
            this.controlPanel.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pbxPreview;
        private System.Windows.Forms.TextBox txtRow;
        private System.Windows.Forms.TextBox txtCol;
        private System.Windows.Forms.Label lblRow;
        private System.Windows.Forms.Label lblCol;
        private System.Windows.Forms.Button btnImageLoad;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btn_UP;
        private System.Windows.Forms.Button btn_Left;
        private System.Windows.Forms.Button btn_Down;
        private System.Windows.Forms.TableLayoutPanel tlpMain;
        private System.Windows.Forms.TableLayoutPanel controlPanel;
        private System.Windows.Forms.Timer GameClock;
    }
}

