﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileReader
{
    internal class PuzzlePictureBox : PictureBox
    {
        private int _ball = 0;
        private int _hole = 0;
        private bool _leftWall = false;
        private bool _topWall = false;
        private bool _bottomWall = false;
        private bool _rightWall = false;
        private bool _error = false;



        public bool ErrorCondition
        {
            get => _error;
            set
            {
                if (_hole == 0) 
                {
                    _error = true;
                }
                else
                {
                    _error = value;  
                }
            }
        }

        public int Ball
        {
            get { return _ball; }
            set { _ball = value; }
        }

        public int Hole
        {

            get { return _hole; }
            set { _hole = value; }
        }

        public bool LeftWall
        {   get { return _leftWall; }
            set { _leftWall = value; }
        }

        public bool TopWall
        {
            get { return _topWall; }
            set { _topWall = value; }

        }

        public bool RightWall
        {
            get { return _rightWall; }
            set { _rightWall = value; }
        }

        public bool BottomWall
        {
            get { return _bottomWall; }
            set { _bottomWall = value; }
        }

    }
}
