﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace _321_Assignment3
{
    public partial class OpenFiles : Form
    {
        private string CurrentDirectory;
        private string ArchiveLocation;
        private string TempDirectory = "";

        public OpenFiles()
        {
            InitializeComponent();
            //directory.getcurrenmt()
            CurrentDirectory = Directory.GetCurrentDirectory();
            InitializeListView();
            UpdateFileList();
            listViewFiles.SelectedIndexChanged += ListViewFiles_SelectedIndexChanged;
        }

        private void InitializeListView()
        {
            listViewFiles.View = View.Details;
            listViewFiles.FullRowSelect = true;
            listViewFiles.MultiSelect = false;
            listViewFiles.DoubleClick += ListViewFiles_DoubleClick;
            listViewFiles.SmallImageList = imageList1;
        }

        private void UpdateFileList()
        {
            try
            {
                listViewFiles.Items.Clear();
                DirectoryInfo directoryInfo = new DirectoryInfo(CurrentDirectory);
                FileInfo[] files = directoryInfo.GetFiles();

                // Add folders
                foreach (DirectoryInfo dir in directoryInfo.GetDirectories())
                {
                    ListViewItem item = new ListViewItem(dir.Name)
                    {
                        Tag = dir.FullName,
                        ImageIndex = 0 // Folder icon
                    };
                    listViewFiles.Items.Add(item);
                }

                // Add files
                foreach (FileInfo fileInfo in files)
                {
                    ListViewItem item = new ListViewItem(fileInfo.Name)
                    {
                        Tag = fileInfo.FullName,
                        ImageIndex = 1 // All other files icon
                    };
                    listViewFiles.Items.Add(item);
                }

                txtCurrentPath.Text = CurrentDirectory;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        private void ListViewFiles_DoubleClick(object sender, EventArgs e)
        {
            if (listViewFiles.SelectedItems.Count > 0)
            {
                string selectedFile = listViewFiles.SelectedItems[0].Tag.ToString();
                string extension = Path.GetExtension(selectedFile).ToLower();

                if (extension == ".mrb")
                {
                    ArchiveLocation = selectedFile;
                    ExtractAndShowImage();
                    ShowGameArchiveInfo();
                }
                else if (extension == ".jpg" || extension == ".png" || extension == ".bmp")
                {
                    LoadImage(selectedFile);
                }
                else if (extension == ".txt")
                {
                    ShowTextFileContent(selectedFile);
                }
                if (Directory.Exists(selectedFile))
                {
                     CurrentDirectory = selectedFile;
                     UpdateFileList();
                }

            }
        }

        private void LoadImage(string filePath)
        {
            try
            {
                using (Image img = Image.FromFile(filePath))
                {
                    Bitmap bm = new Bitmap(pbxPreview.Width, pbxPreview.Height);
                    using (Graphics graphics = Graphics.FromImage(bm))
                    {
                        graphics.DrawImage(img, new Rectangle(0, 0, pbxPreview.Width, pbxPreview.Height),
                            0, 0, img.Width, img.Height, GraphicsUnit.Pixel);
                    }
                    pbxPreview.Image = bm;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading image: " + ex.Message);
            }
        }

        private void ShowTextFileContent(string filePath)
        {
            try
            {
                string content = File.ReadAllText(filePath);
                MessageBox.Show(content, "Text File Content", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening text file: " + ex.Message);
            }
        }

        private void ListViewFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewFiles.SelectedItems.Count > 0)
            {
                string selectedFile = listViewFiles.SelectedItems[0].Tag.ToString();
                if (selectedFile.EndsWith(".mrb"))
                {
                    ArchiveLocation = selectedFile;
                    ExtractAndShowImage();
                }
                else
                {
                    pbxPreview.Image = null;
                }
            }
        }



        //Shows the information regaurding size, ball count, and wall count in the game. Splits the line 0 where that information is to be read in correctly
        private void ShowGameArchiveInfo()
        {
            string textFilePath = Path.Combine(TempDirectory, "puzzle.txt");
            if (File.Exists(textFilePath))
            {
                string[] lines = File.ReadAllLines(textFilePath);
                if (lines.Length > 0)
                {
                    string[] values = lines[0].Split();
                    if (values.Length >= 3)
                    {
                        lblGameSize.Text = $"Size: {values[0]}";
                        lblBallCount.Text = $"Balls: {values[1]}";
                        lblWallCount.Text = $"Walls: {values[2]}";
                    }
                }
            }
        }



        //shows the game grid in base.mrb
        // Extracts files from the .mrb archive and returns the path to the puzzle.txt file
        // In OpenFiles class
        public string ExtractAndShowImage()
        {
            if (File.Exists("puzzle.jpg"))
            {
                TempDirectory = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
                Directory.CreateDirectory(TempDirectory);

                using (ZipArchive archive = ZipFile.OpenRead(ArchiveLocation))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        entry.ExtractToFile(Path.Combine(TempDirectory, entry.FullName), true);
                    }
                }

                LoadImage(Path.Combine(TempDirectory, "puzzle.jpg"));
                return Path.Combine(TempDirectory, "puzzle.jpg");  // Return the path to the extracted image
            }

            // Add a return statement for the case where the file doesn't exist
            return null;  // Return null (or another default value) if the file doesn't exist
        }




        // Define an event to send the path back to Form1
        public event Action<string> FileSelected;

        private void button1_Click(object sender, EventArgs e)
        {
            string newPath = txtCurrentPath.Text;  // Path from the TextBox
            if (Directory.Exists(newPath))
            {
                CurrentDirectory = newPath;  // Set the current directory
                UpdateFileList();  // Update the file list in the OpenFiles form
            }

            // Send the selected path back to Form1
            FileSelected?.Invoke(newPath); // Trigger the event to pass the selected path
            this.Close();  // Close the OpenFiles form after selecting
        }



        //Level one up button
        //Takes you up in the directory and shows you the updated file list in listViewFiles by calling UpdateFileList()
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                DirectoryInfo parentDirectory = Directory.GetParent(CurrentDirectory);
                if (parentDirectory != null)
                {
                    CurrentDirectory = parentDirectory.FullName;
                    UpdateFileList();
                    pbxPreview.Image = null;
                    lblGameSize.Text = null;
                    lblBallCount.Text = null;
                    lblWallCount.Text = null;
                }
                else
                {
                    button2.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void RemoveDirectory()
        {
            try
            {
                Directory.Delete(TempDirectory, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing files: " + ex.Message);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!string.IsNullOrEmpty(TempDirectory))
            {
                RemoveDirectory();
            }
        }
    }
}
